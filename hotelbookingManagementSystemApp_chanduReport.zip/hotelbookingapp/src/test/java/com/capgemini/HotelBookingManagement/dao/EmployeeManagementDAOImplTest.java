package com.capgemini.HotelBookingManagement.dao;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.HotelBookingManagement.bean.EmployeeInfoBean;
import com.capgemini.HotelBookingManagement.factory.HotelBookingFactory;

class EmployeeManagementDAOImplTest {

	static EmployeeManagementDAO employee = HotelBookingFactory.getEmployeeDAOImplInstance();

	EmployeeManagementDAO employee1 = HotelBookingFactory.getEmployeeDAOImplInstance();

	static List<EmployeeInfoBean> employees = new ArrayList<EmployeeInfoBean>();

	@Test
	@BeforeAll
	@DisplayName("EmployeeLogin")
	static void testGetEmployeeLogin() {
		assertEquals(true, employee.getEmployeeLogin());
	}

	@Test
	void testGetAllEmployee() {
		assertNotNull(employee.getAllEmployee());
	}
	@Test
	void testGetCustomerOperations() {
		assertEquals(true, employee.getCustomerOperations());
	}

	@Test
	void testGetBookingOperations() {
		assertEquals(true, employee.getCustomerOperations());
	}

	@Test
	void testAddEmployee() {

		assertEquals(true, employee.addEmployee(new EmployeeInfoBean()));

	}

	@Test
	void testUpdateEmployee() {
		assertEquals(true, employee.updateEmployee(new EmployeeInfoBean()));
	}

	@Test
	void testDeleteEmployee() {
		assertEquals(true, employee.deleteEmployee());

	}

	@Test
	void testGetEmployee() {
		assertEquals(true, employee.getEmployee());
	}


	@Test
	@DisplayName("Invalid EmployeeLogin")
	static void testGetEmployeeLogin1() {
		assertEquals(false, employee.getEmployeeLogin());
	}

	@Test
	@DisplayName("Invalid testGetCustomerOperations1")

	void testGetCustomerOperations1() {
		assertEquals(false, employee.getCustomerOperations());
	}

	@Test
	@DisplayName("Invalid testGetBookingOperations1")
	void testGetBookingOperations1() {
		assertEquals(false, employee.getCustomerOperations());
	}

	@Test
	@DisplayName("Invalid testUpdateEmployee1")
	void testUpdateEmployee1() {
		assertEquals(false, employee.updateEmployee(new EmployeeInfoBean()));
	}

	@Test
	@DisplayName("Invalid testDeleteEmployee1")
	void testDeleteEmployee1() {
		assertEquals(false, employee.deleteEmployee());

	}

	@Test
	@DisplayName("Invalid testGetEmployee1")
	void testGetEmployee1() {
		assertEquals(false, employee.getEmployee());
	}

}
