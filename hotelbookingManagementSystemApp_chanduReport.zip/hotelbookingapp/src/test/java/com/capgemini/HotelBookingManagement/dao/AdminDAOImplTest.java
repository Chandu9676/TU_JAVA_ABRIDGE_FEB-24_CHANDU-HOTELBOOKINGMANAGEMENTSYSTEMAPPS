package com.capgemini.HotelBookingManagement.dao;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.HotelBookingManagement.factory.HotelBookingFactory;

class AdminDAOImplTest {

	static AdminDAO admindao = HotelBookingFactory.getAdminDAOImplInstance();

	@Test
	@BeforeAll
	static void testGetAdminLogin() throws Exception {
		assertEquals(true, admindao.getAdminLogin());
	}

	@Test
	@DisplayName("Invalid Adminlogin")
 void testGetAdminLogin1() throws Exception {
		assertEquals(false, admindao.getAdminLogin());
	}
	@Test
	void testGetEmployeeOparations() {

		assertEquals(true, admindao.getEmployeeOparations());

	}

	@Test
	void testGetHotelOparations() {
		assertEquals(true, admindao.getHotelOparations());
	}

	@Test
	void testGetRoomsOparations() {
		assertEquals(true, admindao.getRoomsOparations());
	}

	@Test
	void testGetReportsOparations() {
		assertEquals(true, admindao.getReportsOparations());
	}

}
