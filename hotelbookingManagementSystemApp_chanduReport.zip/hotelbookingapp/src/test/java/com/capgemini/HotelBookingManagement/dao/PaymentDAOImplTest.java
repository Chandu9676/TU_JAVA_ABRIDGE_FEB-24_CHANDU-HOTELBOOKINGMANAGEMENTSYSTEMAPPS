package com.capgemini.HotelBookingManagement.dao;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.capgemini.HotelBookingManagement.factory.HotelBookingFactory;

class PaymentDAOImplTest {
	
	
	static PaymentDAOImpl payment = HotelBookingFactory.getPaymentDAOImplInstance();

	@Test
	@BeforeAll
	static void testGetPayments() {
		assertEquals(true, payment.getPayments(15000.0,123312331));
	}

	@Test
	void testOnlineBanking() {
		assertEquals(true, payment.onlineBanking());
	}

	@Test
	void testMobileBanking() { 
		assertEquals(true, payment.mobileBanking());
	}

	@Test
	void testPhonepay() {
		assertEquals(true, payment.phonepay());
	}

	@Test
	void testGooglePay() {
		assertEquals(true, payment.googlePay());
	}

}
