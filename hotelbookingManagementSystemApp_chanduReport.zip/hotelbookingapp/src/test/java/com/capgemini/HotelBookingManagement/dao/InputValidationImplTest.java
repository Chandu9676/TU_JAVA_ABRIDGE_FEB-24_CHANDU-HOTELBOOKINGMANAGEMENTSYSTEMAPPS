package com.capgemini.HotelBookingManagement.dao;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.capgemini.HotelBookingManagement.factory.HotelBookingFactory;
import com.capgemini.HotelBookingManagement.validation.InputValidations;

class InputValidationImplTest {

	static InputValidations input = HotelBookingFactory.getInputValidationInstance();
	

	@Test
	void testChoiceValidate() {
		assertEquals(true, input.choiceValidate("3"));
	}
	@Test
	void testChoiceValidate1() {
		assertEquals(false, input.choiceValidate("ch123"));
	}

	@Test
	
	static void testIdValidation() {
		assertEquals(true, input.choiceValidate("1231"));
	}

	@Test
	void testIdValidation1() {
		assertEquals(false, input.idValidation("3121212"));
	}

	@Test
	void testNameValidation() {
		assertEquals(true, input.nameValidation("Hyderabad"));
	}
	
	@Test
	void testNameValidation1() {
		assertEquals(false, input.idValidation("mumbai"));
	}

	@Test
	void testUserNameValidation() {
		assertEquals(true, input.userNameValidation("hyderabad"));
	}

	
	@Test
	void testUserNameValidation1() {
		assertEquals(false, input.userNameValidation("hyderabad1244"));
	}
	
	
	
	@Test
	void testEmailValidation() {
		assertEquals(true, input.emailValidation("abcd@11gmail.com"));
	}

	@Test
	void testEmailValidation1() {
		assertEquals(false, input.emailValidation("abcd.gmail.com"));
	}
	
	
	@Test
	void testPasswordValidate() {
		assertEquals(true, input.passwordValidate("Abcd@111"));
	}

	
	@Test
	void testPasswordValidate1() {
		assertEquals(false, input.passwordValidate("abcd123"));
	}
	
	
	@Test
	void testContactValidation() {
		assertEquals(true, input.contactValidation("9676046060"));
	}

	
	@Test
	void testContactValidation1() {
		assertEquals(false, input.contactValidation("134567891"));
	}

	
	
	@Test
	void testAgeValidation() {
		assertEquals(true, input.ageValidation("25"));
	}

	@Test
	void testAgeValidation1() {
		assertEquals(false, input.ageValidation("225"));
	}
	@Test
	void testSelectinValidation() {
		assertEquals(true, input.selectinValidation("2"));
	}

	@Test
	void testSelectinValidation1() {
		assertEquals(false, input.selectinValidation("25"));
	}

	@Test
	void testDateValidation() {
		assertEquals(true, input.dateValidation("2020-12-12"));
	}

	@Test
	void testDateValidation1() {
		assertEquals(false, input.dateValidation("252-12-34"));
	}

	@Test
	void testFullNameValidate() {
		assertEquals(true, input.fullNameValidate("Taj Hotel"));
	}

	
	@Test
	void testFullNameValidate1() {
		assertEquals(false, input.fullNameValidate("Taj 122"));
	}
	
	
	
	
	@Test
	void testRmNumberValidate() {
		assertEquals(true, input.rmNumberValidate("2004"));
	}

	@Test
	void testRmNumberValidate1() {
		assertEquals(false, input.rmNumberValidate("20041212"));
	}


	@Test
	void testRoomtypeValidate() {
		assertEquals(true, input.roomtypeValidate("Classic-Room"));
	}
	
	@Test
	void testRoomtypeValidate1() {
		assertEquals(false, input.roomtypeValidate("Classic@Room"));
	}

	@Test
	void testCardValidate() {
		assertEquals(true, input.cardValidate("232787878787"));
	}
	
	@Test
	void testCardValidate1() {
		assertEquals(false, input.cardValidate("2327asd78787"));
	}

	@Test
	void testCvvValidate() {
		assertEquals(true, input.cvvValidate("232"));
	} 
	
	@Test
	void testCvvValidate1() {
		assertEquals(false, input.cvvValidate("232asd"));
	}

	@Test
	void testOTPValidate() {
		assertEquals(true, input.oTPValidate("232323"));
	} 
	
	@Test
	void testOTPValidate1() {
		assertEquals(false, input.oTPValidate("2323"));
	}

	@Test
	void testHotelCodeValidate() {
		assertEquals(true, input.hotelCodeValidate("23"));
	}
	@Test
	void testHotelCodeValidate1() {
		assertEquals(false, input.hotelCodeValidate("2311"));
	}

	@Test
	void testHotelNumberValidate() {
		assertEquals(true, input.hotelNumberValidate("23"));
	}

	@Test
	void testHotelNumberValidate1() {
		assertEquals(false, input.hotelNumberValidate("2323"));
	}
}
