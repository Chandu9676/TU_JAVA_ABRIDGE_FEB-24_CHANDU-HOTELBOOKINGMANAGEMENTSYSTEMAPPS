package com.capgemini.HotelBookingManagementApp;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import com.capgemini.HotelBookingManagement.bean.EmployeeInfoBean;
import com.capgemini.HotelBookingManagement.factory.HotelBookingFactory;
import com.capgemini.HotelBookingManagement.service.EmployeeManagement;

public class TestEmployeeService {

	static EmployeeManagement employee = HotelBookingFactory.getEmployeeImplInstance();

	@Test
	@BeforeAll
	@DisplayName("employeeRegistration method1")
	static void employeeRegistration1() {

		assertEquals(true, employee.employeeRegistration(new EmployeeInfoBean()));

	}
}
