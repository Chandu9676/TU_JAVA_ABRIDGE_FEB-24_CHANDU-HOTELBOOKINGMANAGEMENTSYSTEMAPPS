package com.capgemini.HotelBookingManagement.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.HotelBookingManagement.bean.CutomerInfoBean;
import com.capgemini.HotelBookingManagement.controller.HotelBookingController;
import com.capgemini.HotelBookingManagement.exceptions.DetailsNotFoundException;
import com.capgemini.HotelBookingManagement.exceptions.EmployeesNotFoundException;
import com.capgemini.HotelBookingManagement.factory.HotelBookingFactory;
import com.capgemini.HotelBookingManagement.validation.InputValidations;

public class CustomerDAOImpl implements CustomerDAO {

	static final Logger logger = Logger.getLogger(HotelBookingController.class);
	InputValidations inputvalidation = HotelBookingFactory.getInputValidationInstance();
	Scanner sc = new Scanner(System.in);
	static List<CutomerInfoBean> customers = new ArrayList<CutomerInfoBean>();
	static {
		CutomerInfoBean customer1 = HotelBookingFactory.getCustomerInfoInstance();
		customer1.setuserID("2020");
		customer1.setUserName("Naveen");
		customer1.setCustomerMailID("Naveennani111@gmail.com");
		customer1.setCustomerPassword("Naveen@111");
		customer1.setCustomerAge(27);
		customer1.setCustomerMobileNumber(9701234542l);
		customer1.setCustomeraddress("hydearabad,begumpet");

		CutomerInfoBean customer2 = HotelBookingFactory.getCustomerInfoInstance();
		customer2.setuserID("2021");
		customer2.setUserName("srinu");
		customer2.setCustomerMailID("srinu111@gmail.com");
		customer2.setCustomerPassword("Srinu@111");
		customer2.setCustomerAge(26);
		customer2.setCustomerMobileNumber(858878555l);
		customer2.setCustomeraddress("hydearabad,ashoknagar");

		CutomerInfoBean customer3 = HotelBookingFactory.getCustomerInfoInstance();
		customer3.setuserID("2022");
		customer3.setUserName("srinivas");
		customer3.setCustomerMailID("srinu222@gmail.com");
		customer3.setCustomerPassword("Srinu@222");
		customer3.setCustomerAge(26);
		customer3.setCustomerMobileNumber(858878555l);
		customer3.setCustomeraddress("hydearabad,jublie");

		CutomerInfoBean customer4 = HotelBookingFactory.getCustomerInfoInstance();
		customer4.setuserID("2023");
		customer4.setUserName("Sunny");
		customer4.setCustomerMailID("sunny333@gmail.com");
		customer4.setCustomerPassword("Sunny@333");
		customer4.setCustomerAge(28);
		customer4.setCustomerMobileNumber(858878444l);
		customer4.setCustomeraddress("hydearabad,panjagutta");

		CutomerInfoBean customer5 = HotelBookingFactory.getCustomerInfoInstance();
		customer5.setuserID("2024");
		customer5.setUserName("chandu");
		customer5.setCustomerMailID("abhiram555@gmail.com");
		customer5.setCustomerPassword("Srinu@555");
		customer5.setCustomerAge(26);
		customer5.setCustomerMobileNumber(858878333l);
		customer5.setCustomeraddress("hydearabad,begumpet");

		customers.add(customer1);
		customers.add(customer2);
		customers.add(customer3);
		customers.add(customer4);
		customers.add(customer5);
	}

	public CutomerInfoBean getRegistration(CutomerInfoBean customerinfobean) {

		logger.info("Enter your user ID ");
		String customerID = sc.nextLine();
		while (!inputvalidation.idValidation(customerID)) {
			logger.info("please enter valid id format should be [4-5 digits]");
			customerID = sc.nextLine();
		}
		for (CutomerInfoBean customerinfobean1 : customers) {
			while (customerinfobean1.getuserID().equals(customerID)) {
				logger.info("This Id Already used Try Different like [4-5 digits]");
				customerID = sc.nextLine();

				while (!inputvalidation.idValidation(customerID)) {
					logger.info("please enter valid id format should be [4-5 digits]");
					customerID = sc.nextLine();
				}
			}
		}
		customerinfobean.setuserID(customerID);

		logger.info("Enter your User Name");
		String username = sc.nextLine();
		while (!inputvalidation.userNameValidation(username)) {
			logger.info("please enter valid username format should be [First Name]");
			username = sc.nextLine();
		}
		customerinfobean.setUserName(username);

		logger.info("Enter your mailID ");
		String mail = sc.nextLine();
		while (!inputvalidation.emailValidation(mail)) {
			logger.info("please enter valid mail format should be [abcd123@gmail.com]");
			mail = sc.nextLine();
		}

		for (CutomerInfoBean customerinfobean1 : customers) {
			while (customerinfobean1.getCustomerMailID().equals(mail)) {
				logger.info("This user MAIL Already used Try Different mail");
				mail = sc.nextLine();

				while (!inputvalidation.emailValidation(mail)) {
					logger.info("please enter valid Name format should be [abcd@gmail.com]");
					mail = sc.nextLine();
				}
			}

		}
		customerinfobean.setCustomerMailID(mail);

		logger.info("Enter your password ");
		String password = sc.nextLine();
		while (!inputvalidation.passwordValidate(password)) {
			logger.info("please enter valid password should be like [Nani@123]");
			password = sc.nextLine();
		}

		logger.info("Enter your mobileNumber");
		String mno = sc.nextLine();
		while (!inputvalidation.contactValidation(mno)) {
			logger.info("please enter valid mobile number should be [10 Digits]");
			mno = sc.nextLine();
		}

		logger.info("Enter your Age");
		String age = sc.nextLine();
		while (!inputvalidation.ageValidation(age)) {
			logger.info("please enter valid Age should be [10-99]");
			age = sc.nextLine();
		}
		int cusAge = Integer.parseInt(age);

		logger.info("Enter your Address");
		String address = sc.nextLine();
		while (!inputvalidation.addressValidate(address)) {
			logger.info("enter valid address  like  [Panjagutta, hyderabad]");
			address = sc.nextLine();
		}

		customerinfobean.setCustomerPassword(password);
		customerinfobean.setCustomerAge(cusAge);
		customerinfobean.setCustomeraddress(address);
		long mnum = Long.parseLong(mno);
		customerinfobean.setCustomerMobileNumber(mnum);

		int size = customers.size();
		customers.add(customerinfobean);

		if (size == customers.size()) {
			logger.info("Registration Fail");

		} else {
			logger.info("Registration successful");

		}
		return customerinfobean;

	}

	public boolean getLogin() {

		logger.info("User Id :");
		String userID = sc.nextLine();
		while (!inputvalidation.idValidation(userID)) {
			logger.info("please enter valid id format should be [4-5 digits]");
			userID = sc.nextLine();
		}

		logger.info("Password :");
		String userPassword = sc.nextLine();
		while (!inputvalidation.passwordValidate(userPassword)) {
			logger.info("please enter valid password should be like [abcd@123]");
			userPassword = sc.nextLine();
		}

		int count = 0;
		for (CutomerInfoBean customerinfo : customers) {
			if (customerinfo.getuserID().equals(userID) && customerinfo.getCustomerPassword().equals(userPassword)) {
				count++;
			}
		}

		if (count == 1) {
			logger.info("Login Successful");
			return true;
		} else {

			logger.info("------- LOGIN FAIL -------");

			Q: do {
				logger.info("--------------------------");
				logger.info("1.Forgot password");
				logger.info("2.Back");

				String choose = sc.nextLine();
				while (!inputvalidation.selectinValidation(choose)) {
					logger.info("Enter valid choice");
					choose = sc.nextLine();
				}

				int select = Integer.parseInt(choose);
				switch (select) {
				case 1:

					logger.info("Enter your user ID to update password");
					String customerID1 = sc.nextLine();
					while (!inputvalidation.idValidation(customerID1)) {
						logger.info("please enter valid id format should be [4-5 digits]");
						customerID1 = sc.nextLine();
					}

					logger.info("Enter your mailId");
					String mailId = sc.nextLine();
					while (!inputvalidation.emailValidation(mailId)) {
						logger.info("enter valid mail ID");
						mailId = sc.nextLine();
					}
					int countcheck = 0;
					for (CutomerInfoBean customerinfobean : customers) {

						if (customerinfobean.getCustomerMailID().equals(mailId)
								&& customerinfobean.getuserID().equals(customerID1)) {
							countcheck++;
							logger.info("Enter new password");
							String newPassword = sc.nextLine();
							while (!inputvalidation.passwordValidate(newPassword)) {
								logger.info("Enter valid password should be like [Nani@111]");
								newPassword = sc.nextLine();
							}

							customerinfobean.setCustomerPassword(newPassword);
							logger.info("your password changed successfully");
							logger.info("go back and login with your new password");
						}
					}
					if (countcheck == 0) {
						logger.info("Your Enterd details not matched try Again");
					} else {
						logger.info("=======================================");
						break Q;
					}

					break;
				case 2:
					break Q;
				default:
					logger.info("Enter valid choice");
					break;
				}
			} while (true);

			return false;
		}

	}

	public boolean startBooking() {
		HotelDAO hoteldaoimpl = HotelBookingFactory.getHotelDAOImplInstance();

		K: do {
			logger.info("Please select location for Bookings ");
			logger.info("1.Hyderabad");
			logger.info("2.Bangalore");
			logger.info("3.back");
			String cccc = sc.nextLine();
			while (!inputvalidation.selectinValidation(cccc)) {
				logger.info("please enter valid choice (1-3) ");
				cccc = sc.nextLine();
			}
			int optt = Integer.parseInt(cccc);
			switch (optt) {
			case 1:
				hoteldaoimpl.getHotels("Hyderabad");
				break;
			case 2:
				hoteldaoimpl.getHotels("Bangalore");
				break;
			case 3:
				break K;
			}

		} while (true);

		return true;

	}

	public boolean getCustomer() {
		int check = 0;
		logger.info("Enter user ID :");
		String customerID = sc.nextLine();
		while (!inputvalidation.idValidation(customerID)) {
			logger.info("please enter valid id farmat should be [4-5 digits]");
			customerID = sc.nextLine();
		}

		for (CutomerInfoBean customerinfobean : customers) {
			if (customerinfobean.getuserID().equals(customerID)) {
				check++;
				logger.info("customer details found");
				logger.info((customerinfobean));
			}
		}
		try {
			if (check == 0) {
				throw new DetailsNotFoundException();
			} else {

				logger.info("Details updated successfully");
				return true;
			}
		} catch (DetailsNotFoundException e) {
			System.err.println(e.getMessage());
			return false;

		}

	}

	public boolean updateCustomer(CutomerInfoBean customer) {
		int count = 0;
		logger.info("Enter user ID to uppdate details ");
		String customerID = sc.nextLine();
		while (!inputvalidation.idValidation(customerID)) {
			logger.info("please enter valid id farmat should be [4 - 5 digits]");
			customerID = sc.nextLine();
		}

		for (CutomerInfoBean customerinfobean : customers) {
			if (customerinfobean.getuserID().equals(customerID)) {
				count++;
				logger.info("Customer details found");
				logger.info("Enter User Name");
				String username = sc.nextLine();
				while (!inputvalidation.userNameValidation(username)) {
					logger.info("please enter valid username farmat should be [First Name 4-15 characters]");
					username = sc.nextLine();
				}
				customerinfobean.setUserName(username);

				logger.info("Enter your mailID");
				String mail = sc.nextLine();
				while (!inputvalidation.emailValidation(mail)) {
					logger.info("please enter valid mail farmat should be [abcd123@gmail.com]");
					mail = sc.nextLine();
				}

				for (CutomerInfoBean customerinfobean1 : customers) {
					while (customerinfobean1.getCustomerMailID().equals(mail)) {
						logger.info("This user MailID already Exist Try Different mail");
						mail = sc.nextLine();

						while (!inputvalidation.emailValidation(mail)) {
							logger.info("please enter valid mail farmat should be [abcd@gmail.com]");
							mail = sc.nextLine();
						}
					}

				}
				customerinfobean.setCustomerMailID(mail);

				logger.info("Enter your password");
				String password = sc.nextLine();
				while (!inputvalidation.passwordValidate(password)) {
					logger.info("please enter valid password should be like [Nani@123]");
					password = sc.nextLine();
				}

				logger.info("Enter your mobileNumber");
				String mno = sc.nextLine();
				while (!inputvalidation.contactValidation(mno)) {
					logger.info("please enter valid mobile number [10-digits]");
					mno = sc.nextLine();
				}

				logger.info("Enter your Age");
				String age = sc.nextLine();
				while (!inputvalidation.ageValidation(age)) {
					logger.info("please enter valid Age should be [Between 10-99]");
					age = sc.nextLine();
				}
				int cusAge = Integer.parseInt(age);

				logger.info("Enter your Address");
				String address = sc.nextLine();
				while (!inputvalidation.addressValidate(address)) {
					logger.info("enter valid address  like  [6-200 characters]");
					address = sc.nextLine();
				}
				customerinfobean.setUserName(username);
				customerinfobean.setCustomerPassword(password);
				customerinfobean.setCustomerAge(cusAge);
				customerinfobean.setCustomeraddress(address);
				long mnum = Long.parseLong(mno);
				customerinfobean.setCustomerMobileNumber(mnum);
			}
		}
		try {
			if (count == 0) {
				throw new DetailsNotFoundException();
			} else {

				logger.info("Details updated successfully");
				return true;
			}
		} catch (DetailsNotFoundException e) {
			System.err.println(e.getMessage());
			return false;
		}
	}

	public List<CutomerInfoBean> getAllCustomers() {
		int check = 0;
		for (CutomerInfoBean customerinfo : customers) {
			check++;
			System.out.println(customerinfo);
		}

		if (check == 0) {
			logger.info("NO DETAILS FOUND");
			return null;
		} else {
			logger.info("===========================================");
			return customers;
		}

	}

	public boolean getCustomerIDForBooking(String userid) {
		int count = 0;
		for (CutomerInfoBean customerinfo : customers) {

			if (customerinfo.getuserID().equals(userid)) {
				count++;
			}
		}
		if (count == 1) {
			return true;
		} else {
			logger.error("USER ID NOT MATCHED");
			return false;
		}
	}

}
