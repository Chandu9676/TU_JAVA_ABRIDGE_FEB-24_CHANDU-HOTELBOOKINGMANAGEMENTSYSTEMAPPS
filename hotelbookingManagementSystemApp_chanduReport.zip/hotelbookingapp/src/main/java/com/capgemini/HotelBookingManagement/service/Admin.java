package com.capgemini.HotelBookingManagement.service;

public interface Admin {

	public boolean startAdminWorks() throws Exception;

}
