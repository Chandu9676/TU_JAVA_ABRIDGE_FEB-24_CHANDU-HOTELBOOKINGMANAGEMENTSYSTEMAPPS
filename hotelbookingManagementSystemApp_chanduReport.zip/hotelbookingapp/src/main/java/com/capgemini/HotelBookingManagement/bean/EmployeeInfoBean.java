package com.capgemini.HotelBookingManagement.bean;

public class EmployeeInfoBean {
	private String employeeID;
	private String EmployeeName;
	private String employeePosition;
	private long EmployeeMobile;
	private double Employeesalary;
	private String password;
	private String employeeMail;
	private int employeeAge;

	public String getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(String employeeID) {
		this.employeeID = employeeID;
	}

	public String getEmployeeName() {
		return EmployeeName;
	}

	public void setEmployeeName(String employeeName) {
		EmployeeName = employeeName;
	}

	public long getEmployeeMobile() {
		return EmployeeMobile;
	}

	public void setEmployeeMobile(long employeeMobile) {
		EmployeeMobile = employeeMobile;
	}

	public double getEmployeesalary() {
		return Employeesalary;
	}

	public void setEmployeesalary(double employeesalary) {
		Employeesalary = employeesalary;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmployeeMail() {
		return employeeMail;
	}

	public void setEmployeeMail(String employeeMail) {
		this.employeeMail = employeeMail;
	}

	public int getEmployeeAge() {
		return employeeAge;
	}

	public void setEmployeeAge(int employeeAge) {
		this.employeeAge = employeeAge;
	}

	
	/**
	 * @return the employeePosition
	 */
	public String getEmployeePosition() {
		return employeePosition;
	}

	/**
	 * @param employeePosition the employeePosition to set
	 */
	public void setEmployeePosition(String employeePosition) {
		this.employeePosition = employeePosition;
	}

	
	
	@Override
	public String toString() {
		return "[employeeID = " + employeeID + "  EmployeeName = " + EmployeeName + "  employeePosition = "
				+ employeePosition + "  EmployeeMobile = " + EmployeeMobile + "  Employeesalary = " + Employeesalary
				+ "  password = " + password + "  employeeMail = " + employeeMail + "  employeeAge = " + employeeAge + "]\n";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EmployeeInfoBean other = (EmployeeInfoBean) obj;
		if (EmployeeMobile != other.EmployeeMobile)
			return false;
		if (EmployeeName == null) {
			if (other.EmployeeName != null)
				return false;
		} else if (!EmployeeName.equals(other.EmployeeName))
			return false;
		if (Double.doubleToLongBits(Employeesalary) != Double.doubleToLongBits(other.Employeesalary))
			return false;
		if (employeeAge != other.employeeAge)
			return false;
		if (employeeID == null) {
			if (other.employeeID != null)
				return false;
		} else if (!employeeID.equals(other.employeeID))
			return false;
		if (employeeMail == null) {
			if (other.employeeMail != null)
				return false;
		} else if (!employeeMail.equals(other.employeeMail))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		return true;
	}
	
	
	

}
