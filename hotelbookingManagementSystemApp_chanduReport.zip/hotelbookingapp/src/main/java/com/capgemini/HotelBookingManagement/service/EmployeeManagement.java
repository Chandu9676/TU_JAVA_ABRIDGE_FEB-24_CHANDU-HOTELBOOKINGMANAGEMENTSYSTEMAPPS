package com.capgemini.HotelBookingManagement.service;

import com.capgemini.HotelBookingManagement.bean.EmployeeInfoBean;

public interface EmployeeManagement {

	public boolean employeeRegistration(EmployeeInfoBean employeeinfobean);
}
