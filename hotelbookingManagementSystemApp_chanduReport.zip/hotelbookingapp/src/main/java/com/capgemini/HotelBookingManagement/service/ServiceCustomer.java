package com.capgemini.HotelBookingManagement.service;

import com.capgemini.HotelBookingManagement.bean.CutomerInfoBean;

public interface ServiceCustomer {

	public boolean getCustromerRegistration(CutomerInfoBean customerinfobean);


}
