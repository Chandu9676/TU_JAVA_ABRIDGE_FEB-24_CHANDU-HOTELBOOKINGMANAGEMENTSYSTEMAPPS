package com.capgemini.HotelBookingManagement.bean;

public class RoomInfoBean {

	private int roomNumber;
	private String roomType;
	private int roomPrice;
	private int hotelCode;
	private String roomSpecifiedHotel;
	private String specifiedHotellocation;
	private String hotelPlace;
	private String rommStatus;
	

	public String getHotelPlace() {
		return hotelPlace;
	}

	public void setHotelPlace(String hotelPlace) {
		this.hotelPlace = hotelPlace;
	}

	public int getHotelCode() {
		return hotelCode;
	}

	public void setHotelCode(int code) {
		this.hotelCode = code;
	}

	public int getRoomNo() {
		return roomNumber;
	}

	public void setRoomNo(int roomNo) {
		this.roomNumber = roomNo;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public int getRoomPrice() {
		return roomPrice;
	}

	public void setRoomPrice(int roomPrice) {
		this.roomPrice = roomPrice;
	}

	public String getRoomSpecifiedHotel() {
		return roomSpecifiedHotel;
	}

	public void setRoomSpecifiedHotel(String roomSpecifiedHotel) {
		this.roomSpecifiedHotel = roomSpecifiedHotel;
	}

	public String getRommStatus() {
		return rommStatus;
	}

	public void setRommStatus(String rommStatus) {
		this.rommStatus = rommStatus;
	}

	public String getSpecifiedHotellocation() {
		return specifiedHotellocation;
	}

	public void setSpecifiedHotellocation(String specifiedHotellocation) {
		this.specifiedHotellocation = specifiedHotellocation;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RoomInfoBean other = (RoomInfoBean) obj;
		if (hotelCode != other.hotelCode)
			return false;
		if (rommStatus == null) {
			if (other.rommStatus != null)
				return false;
		} else if (!rommStatus.equals(other.rommStatus))
			return false;
		if (roomNumber != other.roomNumber)
			return false;
		if (roomPrice != other.roomPrice)
			return false;
		if (roomSpecifiedHotel == null) {
			if (other.roomSpecifiedHotel != null)
				return false;
		} else if (!roomSpecifiedHotel.equals(other.roomSpecifiedHotel))
			return false;
		if (roomType == null) {
			if (other.roomType != null)
				return false;
		} else if (!roomType.equals(other.roomType))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "[roomNumber = " + roomNumber + "   roomType = " + roomType + "   roomPrice = " + roomPrice
				+ "   hotelCode = " + hotelCode + "   roomSpecifiedHotel = " + roomSpecifiedHotel
				+ "   specifiedHotellocation = " + specifiedHotellocation + "   hotelPlace=" + hotelPlace + "   rommStatus = "
				+ rommStatus + "]\n";
	}

	
}