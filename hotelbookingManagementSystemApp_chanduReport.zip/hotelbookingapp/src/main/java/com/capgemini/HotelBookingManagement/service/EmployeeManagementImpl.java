package com.capgemini.HotelBookingManagement.service;

import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.HotelBookingManagement.bean.EmployeeInfoBean;
import com.capgemini.HotelBookingManagement.controller.HotelBookingController;
import com.capgemini.HotelBookingManagement.dao.EmployeeManagementDAO;
import com.capgemini.HotelBookingManagement.factory.HotelBookingFactory;
import com.capgemini.HotelBookingManagement.validation.InputValidations;

public class EmployeeManagementImpl implements EmployeeManagement {

	static final Logger logger = Logger.getLogger(HotelBookingController.class);
	InputValidations inputvalidation = HotelBookingFactory.getInputValidationInstance();
	Scanner scan = new Scanner(System.in);

	public boolean employeeRegistration(EmployeeInfoBean employeeinfobean) {

		EmployeeManagementDAO employee = HotelBookingFactory.getEmployeeDAOImplInstance();

		boolean value = employee.getEmployeeLogin();

		if (value == true) {
			Z: do {
				logger.info("Select Options bellow ");
				logger.info("1.Customer Operations");
				logger.info("2.Booking Operations");
				logger.info("3.Logout");

				String choose = scan.nextLine();
				while (!inputvalidation.selectinValidation(choose)) {
					logger.info("please enter valid choice ");
					choose = scan.nextLine();
				}

				int chooses = Integer.parseInt(choose);
				switch (chooses) {
				case 1:
					employee.getCustomerOperations();
					break;
				case 2:
					employee.getBookingOperations();
					break;
				case 3:
					break Z;
				default:
					logger.info("Enter Valid choice");
					break;
				}

			} while (true);

		}

		return true;

	}
}
