package com.capgemini.HotelBookingManagement.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.HotelBookingManagement.bean.AdminInfoBean;
import com.capgemini.HotelBookingManagement.bean.EmployeeInfoBean;
import com.capgemini.HotelBookingManagement.bean.HotelInfoBean;
import com.capgemini.HotelBookingManagement.bean.RoomInfoBean;
import com.capgemini.HotelBookingManagement.controller.HotelBookingController;
import com.capgemini.HotelBookingManagement.factory.HotelBookingFactory;
import com.capgemini.HotelBookingManagement.validation.InputValidations;

public class AdminDAOImpl implements AdminDAO {

	Properties p;

	static final Logger logger = Logger.getLogger(HotelBookingController.class);
	InputValidations inputvalidation = HotelBookingFactory.getInputValidationInstance();
	Scanner sc = new Scanner(System.in);
	static List<AdminInfoBean> adminList = new ArrayList<AdminInfoBean>();

	static {
		AdminInfoBean admin1 = HotelBookingFactory.getAdminInfoBeanInstance();

		admin1.setAdminID(54321);
		admin1.setAdminName("Chandu Goud");
		admin1.setAdminMobile(9865326599l);
		admin1.setPassword("Chandu@111");

		adminList.add(admin1);
	}
	HotelDAO hoteldao = HotelBookingFactory.getHotelDAOImplInstance();
	RoomDAO roomdao = HotelBookingFactory.getRoomDAOImplInstance();
	BookingDAO bookingdao = HotelBookingFactory.getBookingDAOImplInstance();

	public boolean getEmployeeOparations() {
		EmployeeManagementDAO employeedao = HotelBookingFactory.getEmployeeDAOImplInstance();

		R: do {

			logger.info("Select operation you want ");
			logger.info("1.Add Employee");
			logger.info("2.Delete employee");
			logger.info("3.update employee");
			logger.info("4.Get employee  details");
			logger.info("5.Get All employees");
			logger.info("6.Back");

			String selection = sc.nextLine();
			while (!inputvalidation.selectionsValidation(selection)) {
				logger.info("please enter valid choice [1-6]");
				selection = sc.nextLine();
			}

			int chance = Integer.parseInt(selection);
			switch (chance) {

			case 1:
				employeedao.addEmployee(new EmployeeInfoBean());
				break;
			case 2:
				employeedao.deleteEmployee();
				break;
			case 3:
				employeedao.updateEmployee(new EmployeeInfoBean());
				break;
			case 4:
				employeedao.getEmployee();
				break;
			case 5:
				employeedao.getAllEmployee();
				break;
			case 6:
				break R;

			}

		} while (true);

		return true;

	}

	public boolean getHotelOparations() {
		R: do {
			HotelDAO hoteldao = HotelBookingFactory.getHotelDAOImplInstance();

			logger.info("Select operation you want ");
			logger.info("1.Add Hotel");
			logger.info("2.Delete Hotel");
			logger.info("3.update hotel");
			logger.info("4.Get Specific Hotel");
			logger.info("5.Get All Hotel List");
			logger.info("6.Back");

			String selection = sc.nextLine();
			while (!inputvalidation.selectionsValidation(selection)) {
				logger.info("please enter valid choice [1-6] ");
				selection = sc.nextLine();
			}

			int chance = Integer.parseInt(selection);
			switch (chance) {

			case 1:
				hoteldao.addHotel(new HotelInfoBean());
				break;
			case 2:
				hoteldao.deleteHotel();
				break;
			case 3:
				hoteldao.updateHotel(new HotelInfoBean());
				break;
			case 4:
				hoteldao.getHotelDetails();
				break;
			case 5:
				hoteldao.getAllHotelsDetails();
				break;
			case 6:
				break R;

			}

		} while (true);

		return true;
	}

	public boolean getRoomsOparations() {

		R: do {
			RoomDAO roomdao = HotelBookingFactory.getRoomDAOImplInstance();

			logger.info("Select operation you want ");
			logger.info("1.Add Room");
			logger.info("2.Delete Room");
			logger.info("3.update Room details");
			logger.info("4.Get Specific Room");
			logger.info("5.Get All Room List");
			logger.info("6.Back");
			String selection = sc.nextLine();
			while (!inputvalidation.selectionsValidation(selection)) {
				logger.info("please enter valid choice [1-6]");
				selection = sc.nextLine();
			}

			int chance = Integer.parseInt(selection);
			switch (chance) {

			case 1:
				roomdao.addRoom(new RoomInfoBean());
				break;
			case 2:
				roomdao.deleteRoom();
				break;
			case 3:
				roomdao.updateRoom(new RoomInfoBean());
				break;
			case 4:
				roomdao.getRoomDetails();
				break;
			case 5:
				roomdao.getAllRooms();
				break;
			case 6:
				break R;
			}

		} while (true);

		return true;
	}

	public boolean getReportsOparations() {

		O: do {
			logger.info("Please select option ");
			logger.info("1.View List of Hotels");
			logger.info("2.View Booking of specified hotel");
			logger.info("3.View guest list of specified hotel");
			logger.info("4.View bookings of specified date");
			logger.info("5.Back");
			String choices = sc.nextLine();
			while (!inputvalidation.selectionsValidation(choices)) {
				logger.info("please enter valid choice [1-6] ");
				choices = sc.nextLine();
			}
			int optt = Integer.parseInt(choices);
			switch (optt) {
			case 1:
				hoteldao.getHotel(optt);

				break;
			case 2:
				hoteldao.getHotel(optt);

				break;
			case 3:
				hoteldao.getListForSpecifiedHotelGuest();
				break;
			case 4:
				bookingdao.getBookingSpecifiedDate();
				break;

			case 5:
				break O;
			default:
				logger.info("please enter valid choice [1-6]");

			}

		} while (true);

		return true;

	}

	public boolean getAdminLogin() throws IOException {

		p = new Properties();
		FileInputStream fis = new FileInputStream("db.properties");
		p.load(fis);
		int propertyId = Integer.parseInt(p.getProperty("userID"));
		String propertyPassword = p.getProperty("password");

		logger.info("Enter Details to Login");
		logger.info("Admin ID :");
		String adminID = sc.nextLine();
		while (!inputvalidation.idValidation(adminID)) {
			logger.info("please enter valid id farmat should be [4-5 digits]");
			adminID = sc.nextLine();
		}

		logger.info("Password :");
		String password = sc.nextLine();
		while (!inputvalidation.passwordValidate(password)) {
			logger.info("please enter valid password should be like [Nani@123]");
			password = sc.nextLine();
		}

		int adminid = Integer.parseInt(adminID);
		int count = 0;
		for (AdminInfoBean admininfobean : adminList) {
			if (adminid == propertyId && (password).equals(propertyPassword)) {
				count++;
			}
		}

		if (count == 1) {
			logger.info("Login Successful");
			return true;

		} else {
			logger.info("Login Fail");
			logger.info("Login deatails not matched please Re-Login");
			return false;
		}

	}
}
