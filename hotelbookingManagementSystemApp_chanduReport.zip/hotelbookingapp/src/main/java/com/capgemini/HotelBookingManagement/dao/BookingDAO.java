package com.capgemini.HotelBookingManagement.dao;

import java.util.List;

import com.capgemini.HotelBookingManagement.bean.BookingInfoBean;
import com.capgemini.HotelBookingManagement.bean.RoomInfoBean;

public interface BookingDAO {

	public RoomInfoBean insertBooking(RoomInfoBean roominfobean, int rooms);

	public List<BookingInfoBean> getAllBookingsDetails();

	public boolean getBookingSpecifiedHotel(String hotelName);

	public boolean getGuestListSpecifiedHotel(String hotelname);

	public boolean getBookingSpecifiedDate();

	public boolean getBookingDetailsforCustomer();
	
	public boolean getBookingDetailsByEmployee();

}
