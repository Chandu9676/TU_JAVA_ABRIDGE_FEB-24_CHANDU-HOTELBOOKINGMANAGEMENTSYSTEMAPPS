package com.capgemini.HotelBookingManagement.bean;

import java.time.LocalDate;

import org.apache.log4j.Logger;
public class BookingInfoBean {
	static final Logger logger = Logger.getLogger(BookingInfoBean.class);

	private int bookingID;
	private int custID;
	private String custName;
	private long phoneNor;
	private int totalprice;
	private String hotelName;
	private int roomNum;
	private String roomType;
	private LocalDate inDate;
	private String intime;
	private LocalDate outdate;
	private String outTime;
	private String hotelLocation;
	private int roomsBooked;
	

	public int getTotalprice() {
		return totalprice;
	}

	public void setTotalprice(int totalprice) {
		this.totalprice = totalprice;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public int getRoomsBooked() {
		return roomsBooked;
	}

	public void setRoomsBooked(int roomsBooked) {
		this.roomsBooked = roomsBooked;
	}

	public String getHotelLocation() {
		return hotelLocation;
	}

	public void setHotelLocation(String hotelLocation) {
		this.hotelLocation = hotelLocation;
	}

	public int getBookingID() {
		return bookingID;
	}

	public void setBookingID(int bookingID) {
		this.bookingID = bookingID;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public int getPrice() {
		return totalprice;
	}

	public void setPrice(int price) {
		this.totalprice = price;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public int getRoomNum() {
		return roomNum;
	}

	public void setRoomNum(int roomNum) {
		this.roomNum = roomNum;
	}

	public LocalDate getInDate() {
		return inDate;
	}

	public void setInDate(LocalDate inDate) {
		this.inDate = inDate;
	}

	public String getIntime() {
		return intime;
	}

	public void setIntime(String intime) {
		this.intime = intime;
	}

	public LocalDate getOutdate() {
		return outdate;
	}

	public void setOutdate(LocalDate outdate) {
		this.outdate = outdate;
	}

	public String getOutTime() {
		return outTime;
	}

	public void setOutTime(String outTime) {
		this.outTime = outTime;
	}

	public long getPhoneNor() {
		return phoneNor;
	}

	public void setPhoneNor(long phoneNor) {
		this.phoneNor = phoneNor;
	}

	/**
	 * @return the custID
	 */
	public int getCustID() {
		return custID;
	}

	/**
	 * @param custID the custID to set
	 */
	public void setCustID(int custID) {
		this.custID = custID;
	}

	
	
	public String toString1() {
		
		return "BookingID : " + bookingID + "\nhotelName : " + hotelName + "\nHotel address : " + hotelLocation +
				"\nroomNum: " + roomNum + "\ntotalprice : " + totalprice +"/-"
				+ "\nNo of rooms booked : "+ roomsBooked +"\nRoom type : " + roomType+ "\nDate : " + inDate + " "+ intime +
				  " To " + outdate + " " + outTime ;
		

	}
	

	@Override
	public String toString() {
		return "[bookingID = " + bookingID + ",   custID = " + custID + ",  custName = " + custName
				+ ",  phoneNor = " + phoneNor + ",  totalprice = " + totalprice + ",  hotelName = " + hotelName + ",  roomNum = "
				+ roomNum + ",  roomType = " + roomType + ",  inDate = " + inDate + ",  intime = " + intime + ",  outdate = "
				+ outdate + ",  outTime = " + outTime + ",  hotelLocation = " + hotelLocation + ",  roomsBooked = " + roomsBooked
				+ "]\n";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BookingInfoBean other = (BookingInfoBean) obj;
		if (bookingID != other.bookingID)
			return false;
		if (custID != other.custID)
			return false;
		if (custName == null) {
			if (other.custName != null)
				return false;
		} else if (!custName.equals(other.custName))
			return false;
		if (hotelLocation == null) {
			if (other.hotelLocation != null)
				return false;
		} else if (!hotelLocation.equals(other.hotelLocation))
			return false;
		if (hotelName == null) {
			if (other.hotelName != null)
				return false;
		} else if (!hotelName.equals(other.hotelName))
			return false;
		if (inDate == null) {
			if (other.inDate != null)
				return false;
		} else if (!inDate.equals(other.inDate))
			return false;
		if (intime == null) {
			if (other.intime != null)
				return false;
		} else if (!intime.equals(other.intime))
			return false;
		if (outTime == null) {
			if (other.outTime != null)
				return false;
		} else if (!outTime.equals(other.outTime))
			return false;
		if (outdate == null) {
			if (other.outdate != null)
				return false;
		} else if (!outdate.equals(other.outdate))
			return false;
		if (phoneNor != other.phoneNor)
			return false;
		if (roomNum != other.roomNum)
			return false;
		if (totalprice != other.totalprice)
			return false;
		return true;
	}

	

}
