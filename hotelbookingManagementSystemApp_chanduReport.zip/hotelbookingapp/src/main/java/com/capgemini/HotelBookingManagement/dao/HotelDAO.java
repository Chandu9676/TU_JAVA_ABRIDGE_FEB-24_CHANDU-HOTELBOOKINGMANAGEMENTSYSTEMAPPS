package com.capgemini.HotelBookingManagement.dao;
import com.capgemini.HotelBookingManagement.bean.HotelInfoBean;

public interface HotelDAO {

	public HotelInfoBean getHotel(int num);

	public boolean addHotel(HotelInfoBean hotel);

	public boolean updateHotel(HotelInfoBean hotel);

	public boolean deleteHotel();
	
	public boolean getHotelDetails();
	
	public boolean getAllHotelsDetails();
	
	public boolean getHotels(String location);
	
	public boolean getListForSpecifiedHotelGuest();

}
