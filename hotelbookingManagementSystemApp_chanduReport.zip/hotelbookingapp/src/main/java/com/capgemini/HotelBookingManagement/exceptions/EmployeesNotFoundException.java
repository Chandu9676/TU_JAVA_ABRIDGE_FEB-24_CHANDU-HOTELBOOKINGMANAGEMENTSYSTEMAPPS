package com.capgemini.HotelBookingManagement.exceptions;

@SuppressWarnings("serial")
public class EmployeesNotFoundException extends Exception {
	String msg = " Details not Found";

	public String getMessage1() {
		return msg;

	}

}
