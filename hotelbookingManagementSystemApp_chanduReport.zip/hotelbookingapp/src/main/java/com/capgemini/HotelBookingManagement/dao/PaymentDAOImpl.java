package com.capgemini.HotelBookingManagement.dao;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.HotelBookingManagement.bean.PaymentInfoBean;
import com.capgemini.HotelBookingManagement.controller.HotelBookingController;
import com.capgemini.HotelBookingManagement.factory.HotelBookingFactory;
import com.capgemini.HotelBookingManagement.validation.InputValidations;

public class PaymentDAOImpl {

	static final Logger logger = Logger.getLogger(HotelBookingController.class);
	InputValidations inputvalidation = HotelBookingFactory.getInputValidationInstance();
	Scanner sc1 = new Scanner(System.in);

	public boolean getPayments(double amount, int id) {
		PaymentInfoBean bean = HotelBookingFactory.getPaymentInfoBeanInstance();
		S: do {
			logger.info("select payment Mode");
			logger.info("Online Banking  : Enter 1");
			logger.info("Mobile Banking  : Enter 2");

			String select = sc1.nextLine();
			while (!inputvalidation.selectinValidation(select)) {
				logger.info("please enter valid format should be [1-3]");
				select = sc1.nextLine();
			}
			int n = Integer.parseInt(select);
			switch (n) {
			case 1:
				logger.info("Well come to online Banking");
				onlineBanking();
				logger.info("====================================");
				logger.info("payment successful \nsave Details further uses");
				bean.setAmount(amount);
				bean.setBookingID(id);
				bean.setPayedDate(LocalDate.now());
				bean.setPayementTime(LocalTime.now());
				logger.info(bean);
				logger.info("====================================");

				break S;
			case 2:
				logger.info("Well come to Mobile Banking");
				mobileBanking();
				logger.info("====================================");
				logger.info("payment successful \nsave Details further uses");
				bean.setAmount(amount);
				bean.setBookingID(id);
				bean.setPayedDate(LocalDate.now());
				bean.setPayementTime(LocalTime.now());
				logger.info(bean);
				logger.info("====================================");
				break S;
			default :
				logger.info("Invalid choice");
				break ;

			}
		} while (true);
		return true;

	}

	public boolean onlineBanking() {

		logger.info("Enter your Card Number    :   ");
		String cardNo = sc1.nextLine();
		while (!inputvalidation.cardValidate(cardNo)) {
			logger.info("please enter valid card should contain 12 digits");
			cardNo = sc1.nextLine();
		}

		logger.info("Enter your CVV Number     :  ");
		String cvv = sc1.nextLine();
		while (!inputvalidation.cvvValidate(cvv)) {
			logger.info("please enter valid cvv should contain 3 digits ");
			cvv = sc1.nextLine();
		}

		logger.info("Enter Account holder Name :  ");
		String name = sc1.nextLine();
		while (!inputvalidation.userNameValidation(name)) {
			logger.info("please enter valid id farmat should be [first name 4-15 characters]");
			name = sc1.nextLine();
		}

		logger.info("Proceed to payment please Enter(yes)");
		String choice1 = sc1.nextLine();
		while (!choice1.equals("yes")) {
			logger.info("Invalid choice please Re-Enter ");
			choice1 = sc1.nextLine();
		}

		logger.info("OTP sent your Mobile number \nEnter your OTP :");
		String no = sc1.nextLine();
		while (!inputvalidation.oTPValidate(no)) {
			logger.info("please enter valid OTP contain 6 digits");
			no = sc1.nextLine();
		}
		return true;

	}

	public boolean mobileBanking() {
		J: do {
			logger.info("select payment option");
			logger.info("Phoneay    :   Enter 1 ");
			logger.info("Googlepay  :   Enter 2 ");
			String nn = sc1.nextLine();
			while (!inputvalidation.selectinValidation(nn)) {
				logger.info("please enter valid selection  [1-3]");
				nn = sc1.nextLine();
			}

			int n1 = Integer.parseInt(nn);
			switch (n1) {
			case 1:

				phonepay();
				break J;
			case 2:
				googlePay();
				break J;

			case 3:
				break J;
			}
		} while (true);

		return true;
	}

	public boolean phonepay() {
		System.out.print("Enter your phonepay mobile number :");
		String mnor = sc1.nextLine();
		while (!inputvalidation.contactValidation(mnor)) {
			logger.info("please enter valid number [10 digits]");
			mnor = sc1.nextLine();
		}

		logger.info("Proceed to payment please Enter(yes) ");
		String choice1 = sc1.nextLine();
		while (!choice1.equals("yes")) {
			logger.info("Invalid choice please Re-Enter ");
			choice1 = sc1.nextLine();
		}
		return true;

	}

	public boolean googlePay() {

		System.out.print("Enter your googlepay mobile number :");
		String mnor = sc1.nextLine();
		while (!inputvalidation.contactValidation(mnor)) {
			logger.info("please enter valid number [10-digits]");
			mnor = sc1.nextLine();
		}

		logger.info("Proceed to payment please Enter(yes) ");
		String choice1 = sc1.nextLine();
		while (!choice1.equals("yes")) {
			logger.info("Invalid choice please Re-Enter ");
			choice1 = sc1.nextLine();
		}
		return true;

	}
}
