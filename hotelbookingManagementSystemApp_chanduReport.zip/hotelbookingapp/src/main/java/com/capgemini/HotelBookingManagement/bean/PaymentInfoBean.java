package com.capgemini.HotelBookingManagement.bean;

import java.time.LocalDate;
import java.time.LocalTime;

public class PaymentInfoBean {
private int bookingID;
private double amount;
private LocalDate payedDate;
private LocalTime PayementTime;


public int getBookingID() {
	return bookingID;
}
public void setBookingID(int bookingID) {
	this.bookingID = bookingID;
}
public double getAmount() {
	return amount;
}
public void setAmount(double amount) {
	this.amount = amount;
}
public LocalDate getPayedDate() {
	return payedDate;
}
public void setPayedDate(LocalDate payedDate) {
	this.payedDate = payedDate;
}
public LocalTime getPayementTime() {
	return PayementTime;
}
public void setPayementTime(LocalTime payementTime) {
	PayementTime = payementTime;
}


@Override
public String toString() {
	return "bookingID = " + bookingID + "\namount = " + amount + "\npayedDate = " + payedDate
			+ "\nPayementTime = " + PayementTime ;
}
	


}
