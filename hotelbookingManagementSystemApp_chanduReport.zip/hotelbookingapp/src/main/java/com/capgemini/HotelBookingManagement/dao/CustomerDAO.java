package com.capgemini.HotelBookingManagement.dao;

import java.util.List;

import com.capgemini.HotelBookingManagement.bean.CutomerInfoBean;

public interface CustomerDAO {

	public CutomerInfoBean getRegistration(CutomerInfoBean customerinfobean);

	public boolean getLogin();

	public boolean startBooking();

	public boolean getCustomer();

	public boolean updateCustomer(CutomerInfoBean customer);

	public List<CutomerInfoBean> getAllCustomers();

	public boolean getCustomerIDForBooking(String userid);

}
